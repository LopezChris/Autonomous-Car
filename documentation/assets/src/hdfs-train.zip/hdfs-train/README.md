## Packages needed to use the `hdfs-model.py` script

~~~
!pip3 install pillow
!pip3 install pydoop
!pip3 install opencv-python
!pip3 install tensorflow
!pip3 install keras
~~~